package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import mylocation.com.nas.ezshop.adapter.CakenisBawalAdapter;

public class recylerCakenis extends AppCompatActivity {

    LinearLayoutManager linearLayoutManager;
    Toolbar toolbar;
    Button btnBawal, btnShawl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyler_cakenis);

        btnBawal = findViewById(R.id.btn_bawal);


        RecyclerView recyclerView = findViewById(R.id.recycler_view);

        toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        linearLayoutManager = new LinearLayoutManager(recylerCakenis.this);
        recyclerView.setLayoutManager(linearLayoutManager);

        List<CakenisBawal> allCakenisBawalInfor = getAllCakenisBawalInfor();
        CakenisBawalAdapter cakenisBawalAdapter = new CakenisBawalAdapter(recylerCakenis.this, allCakenisBawalInfor);
        recyclerView.setAdapter(cakenisBawalAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(recylerCakenis.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(recylerCakenis.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(recylerCakenis.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(recylerCakenis.this, tudungPeople.class);
                startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(recylerCakenis.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(recylerCakenis.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(recylerCakenis.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(recylerCakenis.this, tudungPeople.class);
                startActivity(intent);
        }
        switch (item.getItemId()) {
            case R.id.menu_cart :
                intent = new Intent(recylerCakenis.this, NaelofarCart.class);
                startActivity(intent);
        }



        return super.onOptionsItemSelected(item);
    }


    private List<CakenisBawal> getAllCakenisBawalInfor()

    {
        List<CakenisBawal> allCakenisBawal = new ArrayList<CakenisBawal>();

        allCakenisBawal.add(new CakenisBawal("Blue Gleacher", R.drawable.cakenis1_b));
        allCakenisBawal.add(new CakenisBawal("Moth Cake Square", R.drawable.cakenis2_b));
        allCakenisBawal.add(new CakenisBawal("Moth Cake Blu", R.drawable.cakenis3_b));
        allCakenisBawal.add(new CakenisBawal("Chocolate Shawl", R.drawable.cakenis1_s));
        allCakenisBawal.add(new CakenisBawal("Royal Red", R.drawable.cakenis2_s));
        allCakenisBawal.add(new CakenisBawal("Royal Yellow", R.drawable.cakenis3_s));


        return allCakenisBawal;
    }
}