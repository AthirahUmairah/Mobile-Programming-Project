package mylocation.com.nas.ezshop.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import mylocation.com.nas.ezshop.CakenisBawal;
import mylocation.com.nas.ezshop.R;
import mylocation.com.nas.ezshop.ScarvesDetail;
import mylocation.com.nas.ezshop.activity_cakenis_scarves_detail;

public class CakenisBawalAdapter extends RecyclerView.Adapter<CakenisBawalAdapter.BawalCakenisHolder>{
    public List<CakenisBawal> bawalCakenisList;
    private Context context;
    public CakenisBawalAdapter(Context context, List<CakenisBawal> bawalCakenisList) {
        this.context = context;
        this.bawalCakenisList = bawalCakenisList;
    }

    @NonNull
    @Override
    public BawalCakenisHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View cakenisbawalrow = LayoutInflater.from(parent.getContext()).inflate(R.layout.cakenis_bawal_row,null);

        BawalCakenisHolder bawalCakenisH = new BawalCakenisHolder(cakenisbawalrow);
        return bawalCakenisH;
    }

    @Override
    public void onBindViewHolder(@NonNull BawalCakenisHolder holder, int position) {
        holder.tvCakenis.setText(bawalCakenisList.get(position).getName());
        holder.imgbawalcakenis.setImageResource(bawalCakenisList.get(position).getImage());
    }

    @Override
    public int getItemCount(){return bawalCakenisList.size();} {

    }

    public class BawalCakenisHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView tvCakenis;
        public ImageView imgbawalcakenis;

        public BawalCakenisHolder(View itemView) {
            super(itemView);
            tvCakenis = itemView.findViewById(R.id.tv_cakenis_name);
            imgbawalcakenis = itemView.findViewById(R.id.img_bawal_cakenis);
            itemView.setOnClickListener(this);
        }


        @Override
        public void onClick(View view) {
            Toast.makeText(view.getContext(),"Cakenis: "+ bawalCakenisList.get(getAdapterPosition()).getName(),Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(view.getContext(),activity_cakenis_scarves_detail.class);
            intent.putExtra("cakenis", bawalCakenisList.get(getAdapterPosition()).getName());
            intent.putExtra("cakenisImg", bawalCakenisList.get(getAdapterPosition()).getImage());
            view.getContext().startActivity(intent);

        }
    }
}
