package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import mylocation.com.nas.ezshop.adapter.PeopleBawalAdapter;

public class recyclePeople extends AppCompatActivity {

    LinearLayoutManager linearLayoutManager;
    Toolbar toolbar;
    Button btnBawal, btnShawl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_people);

        btnBawal = findViewById(R.id.btn_bawal);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);

        toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        linearLayoutManager = new LinearLayoutManager(recyclePeople.this);
        recyclerView.setLayoutManager(linearLayoutManager);

        List<PeopleBawal> allBawalPeopleInfor = getAllBawalPeopleInfor();
        PeopleBawalAdapter peoplebawalAdapter = new PeopleBawalAdapter(recyclePeople.this, allBawalPeopleInfor);
        recyclerView.setAdapter(peoplebawalAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(recyclePeople.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(recyclePeople.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(recyclePeople.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(recyclePeople.this, tudungPeople.class);
                startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }


    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(recyclePeople.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(recyclePeople.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(recyclePeople.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.manu_cakenis:
                intent = new Intent(recyclePeople.this, MainActivity.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_cart :
                intent = new Intent(recyclePeople.this, NaelofarCart.class);
                startActivity(intent);
        }



        return super.onOptionsItemSelected(item);
    }


    private List<PeopleBawal> getAllBawalPeopleInfor()

    {
        List<PeopleBawal> allBawalPeople = new ArrayList<PeopleBawal>();

        allBawalPeople.add(new PeopleBawal("Manis Macam U", R.drawable.tudungpeople1_b));
        allBawalPeople.add(new PeopleBawal("Maysaa Square", R.drawable.tudungpeople2_b));
        allBawalPeople.add(new PeopleBawal("Blackie", R.drawable.tudungpeople3_b));
        allBawalPeople.add(new PeopleBawal("Flowery Gold", R.drawable.tudungpeople1_s));
        allBawalPeople.add(new PeopleBawal("Pinky Mine", R.drawable.tudungpeople2_s));
        allBawalPeople.add(new PeopleBawal("Mighty White", R.drawable.tudungpeople3_s));


        return allBawalPeople;
    }
}


