package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class NaelofarCart extends AppCompatActivity {

    Button btnOrder;

    TextView tvQuantity;
    TextView tvBrandData;
    TextView tvName;
    TextView tvPriceData;
    TextView tvTotalPrice;

    String name, brand;
    int quantity, total, price;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_naelofar_cart);

        btnOrder = findViewById(R.id.btn_order);
        tvBrandData = findViewById(R.id.tv_brand1_data);
        tvPriceData = findViewById(R.id.tv_price_data);
        tvTotalPrice = findViewById(R.id.tv_totalprice);
        tvQuantity = findViewById(R.id.tv_quantity_data);
        tvName = findViewById(R.id.tv_name_data);

        Intent intent = getIntent();

        quantity = intent.getIntExtra("quantity",0);
        tvQuantity.setText(""+quantity);

        name = intent.getStringExtra("name");
        tvName.setText(""+name);

        brand = intent.getStringExtra("brand");
        tvBrandData.setText(""+brand);

        price = intent.getIntExtra("price", price);
        tvPriceData.setText(""+price);

        total =0;
        total = quantity*price;
        tvTotalPrice.setText("RM"+ total);

        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(NaelofarCart.this, "Place Your Detail", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(NaelofarCart.this,PlaceDetails.class);
                name = tvName.getText().toString();
                brand = tvBrandData.getText().toString();
               // price = tvPriceData.getText().toString();

                intent.putExtra("brand", brand);
                intent.putExtra("name", name);
                intent.putExtra("quantity", quantity);
                intent.putExtra("total", total);
                startActivity(intent);





            }
        });
    }
}
