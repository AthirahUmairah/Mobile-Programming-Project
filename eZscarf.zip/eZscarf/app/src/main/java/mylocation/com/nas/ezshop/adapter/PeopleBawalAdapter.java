package mylocation.com.nas.ezshop.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import mylocation.com.nas.ezshop.PeopleBawal;
import mylocation.com.nas.ezshop.R;
import mylocation.com.nas.ezshop.activity_cakenis_scarves_detail;
import mylocation.com.nas.ezshop.activity_tudungpeople_scarves_detail;

public class PeopleBawalAdapter extends RecyclerView.Adapter<PeopleBawalAdapter.PeoplebawalHolder>{
    public List<PeopleBawal> bawalPeopleList;
    private Context context;
    public PeopleBawalAdapter(Context context, List<PeopleBawal> bawalPeopleList) {
        this.context = context;
        this.bawalPeopleList = bawalPeopleList;
    }

    @NonNull
    @Override
    public PeopleBawalAdapter.PeoplebawalHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View peoplebawalrow = LayoutInflater.from(parent.getContext()).inflate(R.layout.tudungpeople_bawal_row,null);

        PeopleBawalAdapter.PeoplebawalHolder bawalPeopleH = new PeoplebawalHolder(peoplebawalrow);
        return bawalPeopleH;
    }

    @Override
    public void onBindViewHolder(@NonNull PeopleBawalAdapter.PeoplebawalHolder holder, int position) {
        holder.tvPeople.setText(bawalPeopleList.get(position).getName());
        holder.imgbawalpeople.setImageResource(bawalPeopleList.get(position).getImage());

    }

    @Override
    public int getItemCount(){return bawalPeopleList.size();} {

    }

    public class PeoplebawalHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public ImageView imgbawalpeople;
        public TextView tvPeople;

        public PeoplebawalHolder(View itemView) {
            super(itemView);
            tvPeople = itemView.findViewById(R.id.tv_tp_name);
            imgbawalpeople = itemView.findViewById(R.id.img_bawal_people);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            Toast.makeText(v.getContext(),"People: "+ bawalPeopleList.get(getAdapterPosition()).getName(),Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(v.getContext(),activity_tudungpeople_scarves_detail.class);
            intent.putExtra("people", bawalPeopleList.get(getAdapterPosition()).getName());
            intent.putExtra("peopleImg", bawalPeopleList.get(getAdapterPosition()).getImage());
            v.getContext().startActivity(intent);

        }
    }
}

