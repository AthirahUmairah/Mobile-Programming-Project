package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnbawal, btnLocationMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        btnbawal = findViewById(R.id.btn_bawal);
        btnLocationMap = findViewById(R.id.btn_map);

        setSupportActionBar(toolbar);

        btnbawal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, recylerCakenis.class);
                startActivity(intent);
            }
        });

        btnLocationMap.setOnClickListener(this);

    }


    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(MainActivity.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(MainActivity.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(MainActivity.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(MainActivity.this, tudungPeople.class);
                startActivity(intent);
        }
        switch (item.getItemId()) {
            case R.id.menu_cart :
                intent = new Intent(MainActivity.this, NaelofarCart.class);
                startActivity(intent);
        }



        return super.onOptionsItemSelected(item);
    }


    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_map:
                //Toast.makeText(OrderDetailActivity.this,"Image Button Web",Toast.LENGTH_SHORT).show();
                Uri webpage = Uri.parse("https://www.google.com/maps/search/cakenis+shop/@2.961807,101.7526469,17z/data=!3m1!4b1");
                Intent webIntent = new Intent(Intent.ACTION_VIEW,webpage);

                if (webIntent.resolveActivity(getPackageManager())!=null) { //verify that an app exists to receive the intent
                    startActivity(webIntent);
                }
                else {
                    Toast.makeText(MainActivity.this, "Sorry, no app can handle this action and data",Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }


}
