package mylocation.com.nas.ezshop.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import mylocation.com.nas.ezshop.NaelofarBawal;
import mylocation.com.nas.ezshop.R;
import mylocation.com.nas.ezshop.ScarvesDetail;

public class NaelofarBawalAdapter extends RecyclerView.Adapter<NaelofarBawalAdapter.NaelofarBawalHolder>{

    public List<NaelofarBawal> bawalNaelofarList;
    private Context context;

    public NaelofarBawalAdapter(Context context, List<NaelofarBawal> bawalNaelofarList) {
        this.context = context;
        this.bawalNaelofarList = bawalNaelofarList;
    }

    @NonNull
    @Override
    public NaelofarBawalHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View bawalnaelofarrow = LayoutInflater.from(parent.getContext()).inflate(R.layout.naelofarhijab_bawal_row,null);

        NaelofarBawalHolder bawalNaelofarH = new NaelofarBawalHolder(bawalnaelofarrow);
        return bawalNaelofarH;
    }

    @Override
    public void onBindViewHolder(@NonNull NaelofarBawalHolder holder, int position) {

        holder.tvNaelofar.setText(bawalNaelofarList.get(position).getName());
        holder.imgbawalnaelofar.setImageResource(bawalNaelofarList.get(position).getImage());
    }

    @Override
    public int getItemCount(){return bawalNaelofarList.size();}

    public class NaelofarBawalHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView tvNaelofar;
        public ImageView imgbawalnaelofar;

        public NaelofarBawalHolder(View itemView) {
            super(itemView);
            tvNaelofar = itemView.findViewById(R.id.tv_naelofa_name);
            imgbawalnaelofar = itemView.findViewById(R.id.img_cart_naelofar);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Toast.makeText(view.getContext(),"Naelofar: "+bawalNaelofarList.get(getAdapterPosition()).getName(),Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(view.getContext(),ScarvesDetail.class);
            intent.putExtra("naelofar",bawalNaelofarList.get(getAdapterPosition()).getName());
            intent.putExtra("naelofarImg", bawalNaelofarList.get(getAdapterPosition()).getImage());
            view.getContext().startActivity(intent);

        }
    }
}

