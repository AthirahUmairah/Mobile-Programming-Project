package mylocation.com.nas.ezshop.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import mylocation.com.nas.ezshop.BawalAidijuma;
import mylocation.com.nas.ezshop.NaelofarCart;
import mylocation.com.nas.ezshop.R;
import mylocation.com.nas.ezshop.ScarvesDetail;
import mylocation.com.nas.ezshop.aidijuma_scarves_detail;

public class AidijumaBawalAdapter extends RecyclerView.Adapter<AidijumaBawalAdapter.BawalAidijumaHolder>{
    public List<BawalAidijuma> bawalAidijumaList;
    private Context context;
    public AidijumaBawalAdapter(Context context, List<BawalAidijuma> bawalAidijumaList) {
        this.context = context;
        this.bawalAidijumaList = bawalAidijumaList;
    }

    @NonNull
    @Override
    public BawalAidijumaHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View aidijuma_bawal_row = LayoutInflater.from(parent.getContext()).inflate(R.layout.aidijuma_bawal_row,null);

        BawalAidijumaHolder bawalAidijumaH = new BawalAidijumaHolder(aidijuma_bawal_row);
        return bawalAidijumaH;
    }

    @Override
    public void onBindViewHolder(@NonNull BawalAidijumaHolder holder, int position) {
        holder.tvAidijuma.setText(bawalAidijumaList.get(position).getName());
        holder.imgbawalaidijuma.setImageResource(bawalAidijumaList.get(position).getImage());

    }

    @Override
    public int getItemCount(){return bawalAidijumaList.size();} {

    }

    public class BawalAidijumaHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView tvAidijuma;
        public ImageView imgbawalaidijuma;

        public BawalAidijumaHolder(View itemView)
        {
            super(itemView);
            tvAidijuma = itemView.findViewById(R.id.tv_aj_name);
            imgbawalaidijuma = itemView.findViewById(R.id.img_aidijuma_bawal);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Toast.makeText(view.getContext(),"Aidijuma: "+bawalAidijumaList.get(getAdapterPosition()).getName(),Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(view.getContext(),aidijuma_scarves_detail.class);

            intent.putExtra("aidijuma",bawalAidijumaList.get(getAdapterPosition()).getName());
            intent.putExtra("aidijumaImg", bawalAidijumaList.get(getAdapterPosition()).getImage());
            view.getContext().startActivity(intent);


        }
    }

}
