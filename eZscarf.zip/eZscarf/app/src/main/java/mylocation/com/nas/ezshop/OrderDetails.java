package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class OrderDetails extends AppCompatActivity  {

    TextView tvName, tvPhone, tvAddress, tvBrand,tvPrice, tvQuantity, tvType;
    String name, phone, address, brand, type;
    int quantity,price;
    Button btnMainMenu , btnQuit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);

        btnMainMenu = findViewById(R.id.btn_mainmenu);
        tvName = findViewById(R.id.tv_cus_name);
        tvPhone = findViewById(R.id.tv_phoneNo);
        tvAddress = findViewById(R.id.tv_address);
        tvType = findViewById(R.id.tv_type);
        tvBrand = findViewById(R.id.tv_brand);
        tvPrice = findViewById(R.id.tv_price);
        tvQuantity = findViewById(R.id.tv_quantity);


        btnMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OrderDetails.this, home.class);
                OrderDetails.this.startActivity(intent);            }
        });


        Intent intent = getIntent();

        name = intent.getStringExtra("name");
        phone = intent.getStringExtra("phoneNo");
        address = intent.getStringExtra("address");

        tvName.setText(name);
        tvPhone.setText(phone);
        tvAddress.setText(address);

        brand = intent.getStringExtra("brand");
        type = intent.getStringExtra("pName");
        quantity = intent.getIntExtra("quantity",0);
        price = intent.getIntExtra("price",0);

        tvBrand.setText(brand);
        tvType.setText(type);
        tvQuantity.setText(quantity);
        tvPrice.setText(price);
    }

    public void clickexit(View v){
        moveTaskToBack(true);
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }
}
