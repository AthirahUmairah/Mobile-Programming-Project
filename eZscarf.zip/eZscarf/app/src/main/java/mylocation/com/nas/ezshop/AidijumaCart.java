package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class AidijumaCart extends AppCompatActivity {

    Button btnOrder;

    TextView tvQuantity;
    TextView tvBrand;
    TextView tvName;
    TextView tvPrice;
    TextView tvColour;
    ImageView imageView;

    String name, brand, price;
    int quantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aidijuma_cart);
        btnOrder = findViewById(R.id.btn_order);
        tvBrand = findViewById(R.id.tv_cus_name);
        tvPrice = findViewById(R.id.tv_price);
        tvColour = findViewById(R.id.tv_colour);
        tvQuantity = findViewById(R.id.tv_quantity);
        tvName = findViewById(R.id.tv_cus_name);
        imageView = findViewById(R.id.img_aidijuma_bawal);
        Intent intent = getIntent();

        quantity = intent.getIntExtra("quantity",0);
        tvQuantity.setText(""+quantity);

        name = intent.getStringExtra("name");
        tvName.setText(""+name);

        brand = intent.getStringExtra("brand");
        tvBrand.setText(""+brand);

        price = intent.getStringExtra("price");
        tvPrice.setText(""+price);

        imageView.setImageResource(intent.getIntExtra("imageNael", 1));


        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AidijumaCart.this, "Place Your Detail", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(AidijumaCart.this,PlaceDetails.class);

                startActivity(intent);
            }
        });
    }
    }

