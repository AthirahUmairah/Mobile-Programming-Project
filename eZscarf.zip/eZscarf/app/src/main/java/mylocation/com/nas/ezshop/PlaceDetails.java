package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class PlaceDetails extends AppCompatActivity {

    Button btnConfirmOrder;
    EditText etphonenum, etName,etAddress;
    ImageButton btnCall;
    String name, phone, address, brand, productName;
    int quantity,price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_details);

        Intent receive = getIntent();

        productName = receive.getStringExtra("name");
        brand = receive.getStringExtra("brand");
        quantity = receive.getIntExtra("quantity",0);
        price = receive.getIntExtra("total",0);

        etName = findViewById(R.id.et_name);
        etAddress = findViewById(R.id.et_address);
        etphonenum = findViewById(R.id.et_phonenum);
        btnConfirmOrder = findViewById(R.id.btn_confirmorder);

        btnConfirmOrder.setOnClickListener(new View.OnClickListener() {
           // String name, phoneNo, address;
            @Override
            public void onClick(View v) {
//                name = etName.getText().toString();
//                phoneNo = etphonenum.getText().toString();
//                address = etAddress.getText().toString();


//                Intent intent = new Intent(v.getContext(),OrderDetails.class);
//
//                //User Detail
//                intent.putExtra("name", name);
//                intent.putExtra("phoneNo", phoneNo);
//                intent.putExtra("address", address);

//                //Product Detail
//                intent.putExtra("pName", productName);
//                intent.putExtra("quantity", quantity);
//                intent.putExtra("price", price);
//                intent.putExtra("brand", brand);
//
//                v.getContext().startActivity(intent);
            }
        });

        btnConfirmOrder = findViewById(R.id.btn_confirmorder);

        btnConfirmOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(PlaceDetails.this, "Your Order Has Been Successful.", Toast.LENGTH_SHORT).show();
            }
        });

        btnCall  = findViewById(R.id.btn_call);

        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel: 0168212558"));

                if (callIntent.resolveActivity(getPackageManager())!=null){

                    startActivity(callIntent);

                }

                else{
                    Toast.makeText(PlaceDetails.this, "Sorry, no app can handle this action and data", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }

}
