package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ameeraZaini extends AppCompatActivity implements View.OnClickListener {

    Button btnbawal, btnLocationMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ameera_zaini);
        Toolbar toolbar = findViewById(R.id.toolbar_main);

        setSupportActionBar(toolbar);
        btnbawal = findViewById(R.id.btn_bawal);
        btnLocationMap = findViewById(R.id.btn_map);

        setSupportActionBar(toolbar);

        btnbawal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ameeraZaini.this, recyclerAmeera.class);
                startActivity(intent);
            }
        });

        btnLocationMap.setOnClickListener(this);



    }

    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(ameeraZaini.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.manu_cakenis:
                intent = new Intent(ameeraZaini.this, MainActivity.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(ameeraZaini.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(ameeraZaini.this, tudungPeople.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_cart :
                intent = new Intent(ameeraZaini.this, NaelofarCart.class);
                startActivity(intent);
        }



        return super.onOptionsItemSelected(item);
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option,menu);

        return super.onCreateOptionsMenu(menu);
     }

    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_map:
                //Toast.makeText(OrderDetailActivity.this,"Image Button Web",Toast.LENGTH_SHORT).show();
                Uri webpage = Uri.parse("https://www.google.com/maps/place/Ameera+Zaini/@3.0692313,101.4866893,17z/data=!3m1!4b1!4m5!3m4!1s0x31cc52fa3bed83ab:0xc3d8677fdbbe7dc3!8m2!3d3.0692259!4d101.488878");
                Intent webIntent = new Intent(Intent.ACTION_VIEW,webpage);

                if (webIntent.resolveActivity(getPackageManager())!=null) { //verify that an app exists to receive the intent
                    startActivity(webIntent);
                }
                else {
                    Toast.makeText(ameeraZaini.this, "Sorry, no app can handle this action and data",Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    }

