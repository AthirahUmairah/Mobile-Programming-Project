package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class activity_cakenis_scarves_detail extends AppCompatActivity {

    Button btnPlus, btnMinus, btnCart;
    TextView tvQuantity, tvPrice, tvbrand;
    int quantity, price;
    String name, brand;
    ImageView imageViewN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cakenis_scarves_detail);

        Intent intent = getIntent();

        final TextView tvName = findViewById(R.id.tv_cakenisDetails);
        tvName.setText(intent.getStringExtra("cakenis"));

        final ImageView imgNae = findViewById(R.id.img_cakenis);
        imgNae.setImageResource(intent.getIntExtra("cakenisImg", 1));

        btnPlus = findViewById(R.id.btn_plus);
        btnMinus = findViewById(R.id.btn_minus);
        btnCart = findViewById(R.id.btn_cart);
        tvQuantity = findViewById(R.id.tv_quantity);

        final TextView tvPrice = findViewById(R.id.tv_cPrice);
        tvPrice.setText("RM "+52);


        final TextView tvBrand = findViewById(R.id.tv_cBrand);
        tvBrand.setText("Cakenis");

        quantity = 1;

        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quantity++;
                tvQuantity.setText("" + quantity);
            }
        });

        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quantity--;
                tvQuantity.setText("" + quantity);
            }
        });

        btnCart.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                name = tvName.getText().toString();
                brand = tvBrand.getText().toString();
                price = tvPrice.getText().charAt(3);

                Intent intent = new Intent(activity_cakenis_scarves_detail.this, NaelofarCart.class);
                intent.putExtra("quantity",quantity);
                intent.putExtra("name",name);
                intent.putExtra("brand", brand);
                intent.putExtra("price", price);

                startActivity(intent);
            }
        });


    }
}
