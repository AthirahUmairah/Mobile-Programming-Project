package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

import mylocation.com.nas.ezshop.adapter.AmeeraBawalAdapter;

public class recyclerAmeera extends AppCompatActivity {

    LinearLayoutManager linearLayoutManager;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_ameera);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);

        toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        linearLayoutManager = new LinearLayoutManager(recyclerAmeera.this);
        recyclerView.setLayoutManager(linearLayoutManager);

        List<AmeeraBawal> allAmeeraBawalInfor = getAllAmeeraBawalInfor();
        AmeeraBawalAdapter ameeraBawalAdapter = new AmeeraBawalAdapter(recyclerAmeera.this, allAmeeraBawalInfor);
        recyclerView.setAdapter(ameeraBawalAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(recyclerAmeera.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(recyclerAmeera.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(recyclerAmeera.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(recyclerAmeera.this, tudungPeople.class);
                startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(recyclerAmeera.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.manu_cakenis:
                intent = new Intent(recyclerAmeera.this, MainActivity.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(recyclerAmeera.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(recyclerAmeera.this, tudungPeople.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_cart :
                intent = new Intent(recyclerAmeera.this, NaelofarCart.class);
                startActivity(intent);
        }



        return super.onOptionsItemSelected(item);
    }


    private List<AmeeraBawal> getAllAmeeraBawalInfor()

    {
        List<AmeeraBawal> allBawalAmeera = new ArrayList<AmeeraBawal>();

        allBawalAmeera.add(new AmeeraBawal("Hawaian Jumper", R.drawable.ameerazaini1_b));
        allBawalAmeera.add(new AmeeraBawal("Sweet Peach", R.drawable.ameerazaini2_b));
        allBawalAmeera.add(new AmeeraBawal("Bawal Stripe", R.drawable.ameerazaini3_b));
        allBawalAmeera.add(new AmeeraBawal("Catty Blink", R.drawable.ameerazaini1_s));
        allBawalAmeera.add(new AmeeraBawal("Roses Pink", R.drawable.ameerazaini2_s));
        allBawalAmeera.add(new AmeeraBawal("Chiffon Jacquard", R.drawable.ameerazaini3_s));

        return allBawalAmeera;
    }

}

