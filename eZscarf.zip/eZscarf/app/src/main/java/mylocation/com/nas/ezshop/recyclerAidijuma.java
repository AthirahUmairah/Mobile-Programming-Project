package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import mylocation.com.nas.ezshop.adapter.AidijumaBawalAdapter;

public class recyclerAidijuma extends AppCompatActivity {

    LinearLayoutManager linearLayoutManager;
    Toolbar toolbar;
    Button btnBawal, btnShawl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_aidijuma);

        btnBawal = findViewById(R.id.btn_bawal);


        RecyclerView rv = findViewById(R.id.recycler_view);

        toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        linearLayoutManager = new LinearLayoutManager(recyclerAidijuma.this);
        rv.setLayoutManager(linearLayoutManager);

        List<BawalAidijuma> allBawalAidijumaInfor = getAllBawalAidijumaInfor();
        AidijumaBawalAdapter aidijumaBawalAdapter = new AidijumaBawalAdapter(recyclerAidijuma.this, allBawalAidijumaInfor);
        rv.setAdapter(aidijumaBawalAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
   public boolean onContextItemSelected(MenuItem item) {
       Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(recyclerAidijuma.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
               intent = new Intent(recyclerAidijuma.this, ameeraZaini.class);
                startActivity(intent);
        }

       switch (item.getItemId()) {
            case R.id.menu_naelofar:
             intent = new Intent(recyclerAidijuma.this, naelofarHijab.class);
               startActivity(intent);
        }

       switch (item.getItemId()) {
           case R.id.menu_people:
               intent = new Intent(recyclerAidijuma.this, tudungPeople.class);
               startActivity(intent);
       }

        return super.onOptionsItemSelected(item);
    }


    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;

        switch (item.getItemId()) {
            case R.id.manu_cakenis:
                intent = new Intent(recyclerAidijuma.this, MainActivity.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(recyclerAidijuma.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(recyclerAidijuma.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(recyclerAidijuma.this, tudungPeople.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_cart :
                intent = new Intent(recyclerAidijuma.this, NaelofarCart.class);
                startActivity(intent);
        }



        return super.onOptionsItemSelected(item);
    }

    private List<BawalAidijuma> getAllBawalAidijumaInfor()
    {
        List<BawalAidijuma> allBawalAidijuma = new ArrayList<BawalAidijuma>();

        allBawalAidijuma.add(new BawalAidijuma("Black Label", R.drawable.aidijuma1_b));
        allBawalAidijuma.add(new BawalAidijuma("Bawal Basic Dancer", R.drawable.aidijuma2_b));
        allBawalAidijuma.add(new BawalAidijuma("Pelangi Castle", R.drawable.aidijuma3_b));
        allBawalAidijuma.add(new BawalAidijuma("Shawl Snow Flow", R.drawable.aidijuma1_s));
        allBawalAidijuma.add(new BawalAidijuma("Shawl Green Label", R.drawable.aidijuma2_s));
        allBawalAidijuma.add(new BawalAidijuma("Shawl Pink Plain", R.drawable.aidijuma3_s));


        return allBawalAidijuma;
    }

}


