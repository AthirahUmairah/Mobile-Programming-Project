package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import mylocation.com.nas.ezshop.adapter.NaelofarBawalAdapter;

public class recylerNaelofar extends AppCompatActivity {

    LinearLayoutManager linearLayoutManager;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyler_naelofar);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);

        toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        linearLayoutManager = new LinearLayoutManager(recylerNaelofar.this);
        recyclerView.setLayoutManager(linearLayoutManager);

        List<NaelofarBawal> allNaelofarBawalInfor = getAllNaelofarBawalInfor();

        NaelofarBawalAdapter naelofarBawalAdapter = new NaelofarBawalAdapter(recylerNaelofar.this,allNaelofarBawalInfor);
        recyclerView.setAdapter(naelofarBawalAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(recylerNaelofar.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(recylerNaelofar.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(recylerNaelofar.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(recylerNaelofar.this, tudungPeople.class);
                startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }


    private List<NaelofarBawal> getAllNaelofarBawalInfor()

    {
        List<NaelofarBawal> allNaelofarBawal = new ArrayList<NaelofarBawal>();

        allNaelofarBawal.add(new NaelofarBawal("Basic Green", R.drawable.naelofarhijab1_b));
        allNaelofarBawal.add(new NaelofarBawal("Basic Grey", R.drawable.naelofarhijab2_b));
        allNaelofarBawal.add(new NaelofarBawal("Basic Purple", R.drawable.naelofarhijab3_b));
        allNaelofarBawal.add(new NaelofarBawal("Basic Pink", R.drawable.naelofarhijab1_s));
        allNaelofarBawal.add(new NaelofarBawal("Basic Red", R.drawable.naelofarhijab2_s));
        allNaelofarBawal.add(new NaelofarBawal("Basic Mustard", R.drawable.naelofarhijab3_s));

        return allNaelofarBawal;
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(recylerNaelofar.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(recylerNaelofar.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.manu_cakenis:
                intent = new Intent(recylerNaelofar.this, MainActivity.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(recylerNaelofar.this, tudungPeople.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_cart :
                intent = new Intent(recylerNaelofar.this, NaelofarCart.class);
                startActivity(intent);
        }



        return super.onOptionsItemSelected(item);
    }
}