package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class tudungPeople extends AppCompatActivity implements View.OnClickListener{

    Button btnbawal, btnLocationMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tudung_people);

        btnbawal = findViewById(R.id.btn_bawal);
        btnLocationMap = findViewById(R.id.btn_map);

        Toolbar toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        btnbawal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(tudungPeople.this, recyclePeople.class);
                startActivity(intent);
            }
        });

        btnLocationMap.setOnClickListener(this);


    }

    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(tudungPeople.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(tudungPeople.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_naelofar:
                intent = new Intent(tudungPeople.this, naelofarHijab.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.manu_cakenis:
                intent = new Intent(tudungPeople.this, MainActivity.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_cart :
                intent = new Intent(tudungPeople.this, NaelofarCart.class);
                startActivity(intent);
        }



        return super.onOptionsItemSelected(item);
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option,menu);

        return super.onCreateOptionsMenu(menu);
        }

    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_map:
                //Toast.makeText(OrderDetailActivity.this,"Image Button Web",Toast.LENGTH_SHORT).show();
                Uri webpage = Uri.parse("https://www.google.com/maps/place/TudungPeople+Signature+Boutique/@2.9617963,101.7526469,17z/data=!4m5!3m4!1s0x31cdc912928c96a1:0xaad5ed750ee0e402!8m2!3d2.961762!4d101.754711");
                Intent webIntent = new Intent(Intent.ACTION_VIEW,webpage);

                if (webIntent.resolveActivity(getPackageManager())!=null) { //verify that an app exists to receive the intent
                    startActivity(webIntent);
                }
                else {
                    Toast.makeText(tudungPeople.this, "Sorry, no app can handle this action and data",Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

}


