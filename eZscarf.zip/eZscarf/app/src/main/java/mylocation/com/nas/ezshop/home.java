package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class home extends AppCompatActivity {

     Button btnNaelofar, btnAidijuma, btnPeople, btnAmeera, btnCakenis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnNaelofar = findViewById(R.id.btn_nealofarhijab);
        btnAidijuma = findViewById(R.id.btn_aidijuma);
        btnPeople = findViewById(R.id.btn_people);
        btnAmeera = findViewById(R.id.btn_ameera);
        btnCakenis = findViewById(R.id.btn_cakenis);


        btnCakenis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(home.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btnNaelofar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(home.this, naelofarHijab.class);
                startActivity(intent);
            }
        });

        btnAidijuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(home.this, aidijumaScarf.class);
                startActivity(intent);
            }
        });

        btnPeople.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(home.this, tudungPeople.class);
                startActivity(intent);
            }
        });

        btnAmeera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(home.this, ameeraZaini.class);
                startActivity(intent);
            }
        });
    }
}
