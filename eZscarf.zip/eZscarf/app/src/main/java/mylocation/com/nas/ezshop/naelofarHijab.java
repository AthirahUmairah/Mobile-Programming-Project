package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class naelofarHijab extends AppCompatActivity implements View.OnClickListener {

    Button btnbawal, btnLocationMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_naelofar_hijab);
        Toolbar toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        btnbawal = findViewById(R.id.btn_bawal);
        btnLocationMap = findViewById(R.id.btn_map);

        setSupportActionBar(toolbar);

        btnbawal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(naelofarHijab.this, recylerNaelofar.class);
                startActivity(intent);
            }
        });

        btnLocationMap.setOnClickListener(this);

    }

    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;

        switch (item.getItemId()) {
            case R.id.menu_aidijuma:
                intent = new Intent(naelofarHijab.this, aidijumaScarf.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_ameera:
                intent = new Intent(naelofarHijab.this, ameeraZaini.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.manu_cakenis:
                intent = new Intent(naelofarHijab.this, MainActivity.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_people:
                intent = new Intent(naelofarHijab.this, tudungPeople.class);
                startActivity(intent);
        }

        switch (item.getItemId()) {
            case R.id.menu_cart :
                intent = new Intent(naelofarHijab.this, NaelofarCart.class);
                startActivity(intent);
        }



        return super.onOptionsItemSelected(item);
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option,menu);

        return super.onCreateOptionsMenu(menu);
       }

    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_map:
                //Toast.makeText(OrderDetailActivity.this,"Image Button Web",Toast.LENGTH_SHORT).show();
                Uri webpage = Uri.parse("https://www.google.com/maps/search/naelofar+shop/@2.9209853,101.6381372,11z/data=!3m1!4b1");
                Intent webIntent = new Intent(Intent.ACTION_VIEW,webpage);

                if (webIntent.resolveActivity(getPackageManager())!=null) { //verify that an app exists to receive the intent
                    startActivity(webIntent);
                }
                else {
                    Toast.makeText(naelofarHijab.this, "Sorry, no app can handle this action and data",Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    }

