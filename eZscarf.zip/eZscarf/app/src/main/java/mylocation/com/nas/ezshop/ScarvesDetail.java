package mylocation.com.nas.ezshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ScarvesDetail extends AppCompatActivity {

    Button btnPlus, btnMinus, btnCart;
    TextView tvQuantity, tvPrice, tvbrand;
    int quantity, price, total;
    String name, brand;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scarves_detail);

        Intent intent = getIntent();

        final TextView tvName = findViewById(R.id.tv_name_scarves);
        tvName.setText(intent.getStringExtra("naelofar"));

        final ImageView imgNae = findViewById(R.id.img_details);
        imgNae.setImageResource(intent.getIntExtra("naelofarImg", 1));

        btnPlus = findViewById(R.id.btn_plus);
        btnMinus = findViewById(R.id.btn_minus);
        btnCart = findViewById(R.id.btn_cart);
        tvQuantity = findViewById(R.id.tv_quantity);

        final TextView tvPrice = findViewById(R.id.tv_price);
        tvPrice.setText("RM "+82);


        final TextView tvBrand = findViewById(R.id.tv_cus_name);
        tvBrand.setText("Naelofar");

        quantity = 1;

        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quantity++;
                tvQuantity.setText("" + quantity);
            }
        });

        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quantity--;
                tvQuantity.setText("" + quantity);
            }
        });

        btnCart.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                name = tvName.getText().toString();
                brand = tvBrand.getText().toString();
                price = tvPrice.getText().charAt(0);



                Intent intent = new Intent(ScarvesDetail.this, NaelofarCart.class);
                intent.putExtra("quantity",quantity);
                intent.putExtra("name",name);
                intent.putExtra("brand", brand);
                intent.putExtra("price", price);

                startActivity(intent);
            }
        });


    }

}
