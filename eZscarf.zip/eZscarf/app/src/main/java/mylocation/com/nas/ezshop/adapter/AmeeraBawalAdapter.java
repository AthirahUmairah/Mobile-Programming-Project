package mylocation.com.nas.ezshop.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import mylocation.com.nas.ezshop.AmeeraBawal;
import mylocation.com.nas.ezshop.R;
import mylocation.com.nas.ezshop.activity_ameerazaini_scarves_detail;

public class AmeeraBawalAdapter extends RecyclerView.Adapter<AmeeraBawalAdapter.AmeeraBawalHolder>{
    public List<AmeeraBawal> bawalAmeeraList;
    private Context context;
    public AmeeraBawalAdapter(Context context, List<AmeeraBawal> bawalAmeeraList) {
        this.context = context;
        this.bawalAmeeraList = bawalAmeeraList;
    }

    @NonNull
    @Override
    public AmeeraBawalHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View bawalameerarow = LayoutInflater.from(parent.getContext()).inflate(R.layout.ameerazaini_bawal_row,null);
        AmeeraBawalHolder bawalAmeeraH = new AmeeraBawalHolder(bawalameerarow);

        return bawalAmeeraH;
    }

    @Override
    public void onBindViewHolder(@NonNull AmeeraBawalAdapter.AmeeraBawalHolder holder, int position) {
        holder.imgbawalameera.setImageResource(bawalAmeeraList.get(position).getImage());
        holder.tvAmeera.setText(bawalAmeeraList.get(position).getName());

    }

    @Override
    public int getItemCount(){return bawalAmeeraList.size();} {

    }

    public class AmeeraBawalHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public ImageView imgbawalameera;
        public TextView tvAmeera;

        public AmeeraBawalHolder(View itemView) {
            super(itemView);
            tvAmeera = itemView.findViewById(R.id.tv_az_name);
            imgbawalameera = itemView.findViewById(R.id.img_bawal_ameera);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            Toast.makeText(v.getContext(),"Ameera Zaini: "+ bawalAmeeraList.get(getAdapterPosition()).getName(),Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(v.getContext(),activity_ameerazaini_scarves_detail.class);
            intent.putExtra("ameera", bawalAmeeraList.get(getAdapterPosition()).getName());
            intent.putExtra("ameeraImg", bawalAmeeraList.get(getAdapterPosition()).getImage());
            v.getContext().startActivity(intent);

        }
    }
}

